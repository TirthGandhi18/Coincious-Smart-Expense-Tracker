# Non-functional requirements


### NFR-01 - Usability(user-friendly)
Identified by: User surveys

### NFR-02 - Performance (fast and smooth)
Identified by: User experience best practices

### NFR-03 - Security
Identified by: Industry standards for data privacy.

### NFR-04 - Reliability
Identified by: Stakeholder expectations

### NFR-05 - Maintainability(clean and organized code)
Identified by: Development team best practices.

### NFR-06 - Scalability
Identified by:  Brainstorming

---

#### Further explanation provided at "User stories" and "Elicitation techniques"
